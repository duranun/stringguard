package com.stringguard.runtime

/**
 * Runtime entry point. The compiler plugin rewrites obfuscated String literals
 * into calls that pass the encrypted payload as a ByteArray (never a String),
 * so a `strings` scan of the binary finds nothing. Works identically on every
 * Kotlin target (JVM, Android, Native/iOS, JS, Wasm).
 *
 * Honest limitation: the key is derivable on-device (the mask is computable from
 * the nonce). This raises the cost of static analysis and defeats casual
 * `strings`/decompilation; it is not cryptographic secrecy.
 */
public object StringGuard {
    public fun reveal(payload: ByteArray): String = StringGuardCodec.decode(payload)
}

/** Stable public symbol the generated IR call resolves to. */
public fun stringGuardReveal(payload: ByteArray): String = StringGuardCodec.decode(payload)
