package com.stringguard.runtime

/**
 * Pure-Kotlin AES block cipher, encryption only (GCM needs E(K, .) for both the
 * counter keystream and the GHASH subkey). Canonical state-array implementation;
 * supports AES-128/192/256 via the standard key schedule.
 */
internal class Aes(key: ByteArray) {
    private val rounds: Int = key.size / 4 + 6
    private val roundKey: ByteArray // (rounds+1) * 16 bytes

    init {
        val nk = key.size / 4
        val totalWords = 4 * (rounds + 1)
        val w = IntArray(totalWords)
        for (i in 0 until nk) {
            w[i] = ((key[4 * i].toInt() and 0xff) shl 24) or
                ((key[4 * i + 1].toInt() and 0xff) shl 16) or
                ((key[4 * i + 2].toInt() and 0xff) shl 8) or
                (key[4 * i + 3].toInt() and 0xff)
        }
        var rcon = 1
        for (i in nk until totalWords) {
            var temp = w[i - 1]
            if (i % nk == 0) {
                temp = subWord(rotWord(temp)) xor (rcon shl 24)
                rcon = xtime(rcon)
            } else if (nk > 6 && i % nk == 4) {
                temp = subWord(temp)
            }
            w[i] = w[i - nk] xor temp
        }
        roundKey = ByteArray(totalWords * 4)
        for (i in 0 until totalWords) {
            roundKey[4 * i] = (w[i] ushr 24).toByte()
            roundKey[4 * i + 1] = (w[i] ushr 16).toByte()
            roundKey[4 * i + 2] = (w[i] ushr 8).toByte()
            roundKey[4 * i + 3] = w[i].toByte()
        }
    }

    /** Encrypts one 16-byte block. */
    fun encryptBlock(input: ByteArray): ByteArray {
        val s = input.copyOf(16)
        addRoundKey(s, 0)
        for (round in 1 until rounds) {
            subBytes(s); shiftRows(s); mixColumns(s); addRoundKey(s, round)
        }
        subBytes(s); shiftRows(s); addRoundKey(s, rounds)
        return s
    }

    private fun addRoundKey(s: ByteArray, round: Int) {
        val off = round * 16
        for (i in 0 until 16) s[i] = (s[i].toInt() xor roundKey[off + i].toInt()).toByte()
    }

    private fun subBytes(s: ByteArray) {
        for (i in 0 until 16) s[i] = SBOX[s[i].toInt() and 0xff].toByte()
    }

    private fun shiftRows(s: ByteArray) {
        val t = s.copyOf(16)
        for (r in 1 until 4) for (c in 0 until 4) {
            s[r + 4 * c] = t[r + 4 * ((c + r) % 4)]
        }
    }

    private fun mixColumns(s: ByteArray) {
        for (c in 0 until 4) {
            val i = 4 * c
            val a0 = s[i].toInt() and 0xff; val a1 = s[i + 1].toInt() and 0xff
            val a2 = s[i + 2].toInt() and 0xff; val a3 = s[i + 3].toInt() and 0xff
            s[i] = (mul2(a0) xor mul3(a1) xor a2 xor a3).toByte()
            s[i + 1] = (a0 xor mul2(a1) xor mul3(a2) xor a3).toByte()
            s[i + 2] = (a0 xor a1 xor mul2(a2) xor mul3(a3)).toByte()
            s[i + 3] = (mul3(a0) xor a1 xor a2 xor mul2(a3)).toByte()
        }
    }

    companion object {
        private fun rotWord(w: Int) = (w shl 8) or (w ushr 24)
        private fun subWord(w: Int) =
            (SBOX[(w ushr 24) and 0xff] shl 24) or (SBOX[(w ushr 16) and 0xff] shl 16) or
                (SBOX[(w ushr 8) and 0xff] shl 8) or SBOX[w and 0xff]

        private fun xtime(x: Int): Int {
            val s = x shl 1
            return if (s and 0x100 != 0) (s xor 0x11b) and 0xff else s and 0xff
        }
        private fun mul2(x: Int) = xtime(x)
        private fun mul3(x: Int) = xtime(x) xor x

        private val SBOX = IntArray(256)
        init {
            val anti = IntArray(256); val log = IntArray(256)
            var a = 1
            for (i in 0 until 255) {
                anti[i] = a
                log[a] = i
                a = (a xor xtime(a)) and 0xff
            }
            val inv = IntArray(256)
            inv[0] = 0
            for (i in 1 until 256) inv[i] = anti[(255 - log[i]) % 255]
            for (i in 0 until 256) {
                val sInv = inv[i]
                var x = sInv
                var acc = sInv
                for (shift in 1..4) {
                    x = ((x shl 1) or (x ushr 7)) and 0xff
                    acc = acc xor x
                }
                SBOX[i] = (acc xor 0x63) and 0xff
            }
        }
    }
}
