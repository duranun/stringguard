package com.stringguard.runtime

/**
 * Decoder for the StringGuard v1 payload. Pure-Kotlin AES-GCM, identical on
 * every Kotlin target. Encryption is done at compile time by the plugin.
 *
 * Layout: [0]=version(1) | [1..32]=masked key | [33..44]=nonce | [45..]=ct||tag
 * key = maskedKey XOR SHA-256("StringGuard/v1" || nonce)
 */
internal object StringGuardCodec {
    private const val VERSION: Byte = 1
    private const val KEY_LEN = 32
    private const val NONCE_LEN = 12
    private val MASK_PREFIX = "StringGuard/v1".encodeToByteArray()

    fun decode(payload: ByteArray): String {
        require(payload.isNotEmpty() && payload[0] == VERSION) { "Unsupported StringGuard payload" }
        val headerEnd = 1 + KEY_LEN + NONCE_LEN
        require(payload.size > headerEnd) { "Truncated StringGuard payload" }

        val maskedKey = payload.copyOfRange(1, 1 + KEY_LEN)
        val nonce = payload.copyOfRange(1 + KEY_LEN, headerEnd)
        val cipherText = payload.copyOfRange(headerEnd, payload.size)

        val mask = Sha256.digest(MASK_PREFIX + nonce)
        val key = ByteArray(KEY_LEN) { (maskedKey[it].toInt() xor mask[it].toInt()).toByte() }

        return Gcm.decrypt(key, nonce, cipherText).decodeToString()
    }
}
