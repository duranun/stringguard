package com.stringguard.runtime

/**
 * Pure-Kotlin AES-GCM decryption (NIST SP 800-38D) with a 96-bit nonce and no
 * AAD, matching the compile-time encryption. Throws on authentication failure.
 */
internal object Gcm {
    private const val TAG_LEN = 16

    fun decrypt(key: ByteArray, nonce: ByteArray, cipherTextWithTag: ByteArray): ByteArray {
        require(nonce.size == 12) { "GCM nonce must be 96 bits" }
        require(cipherTextWithTag.size >= TAG_LEN) { "ciphertext too short" }
        val aes = Aes(key)

        val ctLen = cipherTextWithTag.size - TAG_LEN
        val cipherText = cipherTextWithTag.copyOfRange(0, ctLen)
        val tag = cipherTextWithTag.copyOfRange(ctLen, cipherTextWithTag.size)

        val h = aes.encryptBlock(ByteArray(16))

        // J0 = nonce || 0x00000001
        val j0 = ByteArray(16)
        nonce.copyInto(j0, 0, 0, 12)
        j0[15] = 1

        // Expected tag = GHASH(H, C) XOR E(K, J0)
        val s = ghash(h, cipherText)
        val eqJ0 = aes.encryptBlock(j0)
        val expectedTag = ByteArray(TAG_LEN) { (s[it].toInt() xor eqJ0[it].toInt()).toByte() }
        if (!constantTimeEquals(expectedTag, tag)) {
            throw IllegalStateException("StringGuard: authentication tag mismatch")
        }

        // Plaintext = CTR(inc32(J0)) XOR C
        val plain = ByteArray(ctLen)
        val counter = j0.copyOf(16)
        var offset = 0
        while (offset < ctLen) {
            incr32(counter)
            val keystream = aes.encryptBlock(counter)
            val n = minOf(16, ctLen - offset)
            for (i in 0 until n) {
                plain[offset + i] = (cipherText[offset + i].toInt() xor keystream[i].toInt()).toByte()
            }
            offset += n
        }
        return plain
    }

    private fun ghash(h: ByteArray, data: ByteArray): ByteArray {
        val y = ByteArray(16)
        var i = 0
        while (i < data.size) {
            val n = minOf(16, data.size - i)
            for (j in 0 until n) y[j] = (y[j].toInt() xor data[i + j].toInt()).toByte()
            gfMul(y, h)
            i += 16
        }
        // length block: [0 (AAD bits)] [ctLen bits]
        val lenBlock = ByteArray(16)
        val ctBits = data.size.toLong() * 8
        for (k in 0 until 8) lenBlock[8 + k] = ((ctBits ushr ((7 - k) * 8)) and 0xff).toByte()
        for (j in 0 until 16) y[j] = (y[j].toInt() xor lenBlock[j].toInt()).toByte()
        gfMul(y, h)
        return y
    }

    /** y = y * h in GF(2^128) with reduction polynomial 0xE1..., result into y. */
    private fun gfMul(y: ByteArray, h: ByteArray) {
        val z = ByteArray(16)
        val v = h.copyOf(16)
        for (i in 0 until 128) {
            val bit = (y[i / 8].toInt() ushr (7 - (i % 8))) and 1
            if (bit == 1) for (k in 0 until 16) z[k] = (z[k].toInt() xor v[k].toInt()).toByte()
            // v = v >> 1, if lsb was 1 xor 0xe1 into first byte
            val lsb = v[15].toInt() and 1
            for (k in 15 downTo 1) {
                v[k] = (((v[k].toInt() and 0xff) ushr 1) or ((v[k - 1].toInt() and 1) shl 7)).toByte()
            }
            v[0] = ((v[0].toInt() and 0xff) ushr 1).toByte()
            if (lsb == 1) v[0] = (v[0].toInt() xor 0xe1).toByte()
        }
        z.copyInto(y)
    }

    private fun incr32(counter: ByteArray) {
        for (k in 15 downTo 12) {
            val v = (counter[k].toInt() and 0xff) + 1
            counter[k] = v.toByte()
            if (v <= 0xff) break
        }
    }

    private fun constantTimeEquals(a: ByteArray, b: ByteArray): Boolean {
        if (a.size != b.size) return false
        var r = 0
        for (i in a.indices) r = r or (a[i].toInt() xor b[i].toInt())
        return r == 0
    }
}
