package com.stringguard.guard
internal actual fun platformDebuggerAttached(): Boolean = false
