package com.stringguard.guard

/** A snapshot of runtime self-protection signals. */
public data class GuardReport(
    val debuggerAttached: Boolean,
) {
    /** True if any dynamic-analysis signal fired. */
    public val suspicious: Boolean get() = debuggerAttached
}

/**
 * Runtime self-protection (RASP) entry point. Dynamic-analysis detection plus a
 * degrade policy so protected values yield garbage instead of crashing when an
 * analysis environment is detected (a crash would point an attacker straight at
 * the check). Platform-specific detection lives in `expect`/`actual`.
 *
 * Honest limitation: every RASP signal can itself be bypassed (Frida can hook
 * the detector). This raises cost; it is not a guarantee.
 */
public object Guard {
    public fun report(): GuardReport = GuardReport(
        debuggerAttached = platformDebuggerAttached(),
    )

    /**
     * Runs [block] and returns its result, unless a dynamic-analysis signal is
     * detected, in which case [onDetected] is returned (silent degrade).
     */
    public inline fun <T> protect(onDetected: () -> T, block: () -> T): T =
        if (report().suspicious) onDetected() else block()
}

/** Deterministically scrambles a revealed value so analysis sees plausible junk. */
public fun degrade(original: String): String {
    val sb = StringBuilder(original.length)
    for (c in original) sb.append(((c.code xor 0x5A) % 95 + 32).toChar())
    return sb.toString()
}

/** Platform dynamic-analysis probe. */
internal expect fun platformDebuggerAttached(): Boolean
