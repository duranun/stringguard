package com.stringguard.guard

/**
 * Apple (iOS/macOS) debugger detection.
 *
 * TODO(Faz 3): real detection via `sysctl(KERN_PROC, getpid())` and the
 * `P_TRACED` flag in `kinfo_proc`. Those symbols are not exposed by the default
 * `platform.posix` interop, so this needs a small cinterop `.def` (`<sys/sysctl.h>`,
 * `<sys/proc.h>`). Until then this is a conservative no-op so the module builds
 * and the JVM detector + degrade policy are usable.
 */
internal actual fun platformDebuggerAttached(): Boolean = false
