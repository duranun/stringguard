package com.stringguard.guard

import java.lang.management.ManagementFactory

internal actual fun platformDebuggerAttached(): Boolean = runCatching {
    val args = ManagementFactory.getRuntimeMXBean().inputArguments
    args.any { it.contains("-agentlib:jdwp") || it.contains("-Xdebug") || it.contains("-Xrunjdwp") }
}.getOrDefault(false)
