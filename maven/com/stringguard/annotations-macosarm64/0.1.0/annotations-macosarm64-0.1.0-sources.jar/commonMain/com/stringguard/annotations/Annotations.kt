package com.stringguard.annotations

/**
 * Marks a scope whose String literals should be obfuscated at compile time.
 *
 * Can be applied to a class, function, property or whole file. Every String
 * literal textually contained in the annotated scope is encrypted by the
 * StringGuard compiler plugin and replaced with a call that decrypts it at
 * runtime, so the plaintext never appears in the compiled binary.
 *
 * Literals can be excluded with [KeepPlain] or by the `keepRules` DSL.
 */
@Target(
    AnnotationTarget.CLASS,
    AnnotationTarget.FUNCTION,
    AnnotationTarget.PROPERTY,
    AnnotationTarget.FILE,
    AnnotationTarget.CONSTRUCTOR,
)
@Retention(AnnotationRetention.BINARY)
public annotation class Obfuscate

/**
 * Excludes a scope or property from obfuscation even if an enclosing scope is
 * annotated with [Obfuscate]. Useful for strings consumed by reflection,
 * resource lookups, or anything that must stay readable in the binary.
 */
@Target(
    AnnotationTarget.CLASS,
    AnnotationTarget.FUNCTION,
    AnnotationTarget.PROPERTY,
    AnnotationTarget.CONSTRUCTOR,
)
@Retention(AnnotationRetention.BINARY)
public annotation class KeepPlain

/**
 * Alias of [KeepPlain] for the project-wide (obfuscate-all) workflow: when
 * StringGuard obfuscates every literal by default, mark a class, file,
 * function or property with `@DontObfuscate` to leave its literals readable.
 * Semantically identical to [KeepPlain]; both are honored by the plugin.
 */
@Target(
    AnnotationTarget.CLASS,
    AnnotationTarget.FUNCTION,
    AnnotationTarget.PROPERTY,
    AnnotationTarget.FILE,
    AnnotationTarget.CONSTRUCTOR,
)
@Retention(AnnotationRetention.BINARY)
public annotation class DontObfuscate

/**
 * Reserved for the premium runtime self-protection (RASP) layer (roadmap Faz 3):
 * decrypt sites inside the annotated scope will be woven with dynamic-analysis
 * guard checks. No-op until the `guard` module ships.
 */
@Target(
    AnnotationTarget.CLASS,
    AnnotationTarget.FUNCTION,
)
@Retention(AnnotationRetention.BINARY)
public annotation class GuardWith
